package ntnu.idat2001;

/**
 * A class used only for running the program
 * Uses the class Deck
 * @author Martin Iversen
 * @version 1.0
 * @date Last update 24.01.2020
 */
public class Main {
    public static void main(String[] args) {
        Deck Deck = new Deck();

    }

}
